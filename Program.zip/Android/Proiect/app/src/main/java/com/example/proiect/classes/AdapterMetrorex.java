package com.example.proiect.classes;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.proiect.R;

import java.util.List;

public class AdapterMetrorex extends ArrayAdapter<Metrorex> {


    private Context context;
    private int resource;
    private List<Metrorex> metrouri;
    private LayoutInflater inflater;


    public AdapterMetrorex(@NonNull Context context,
                          int resource, @NonNull List<Metrorex> objects,
                          LayoutInflater inflater) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
        this.metrouri = objects;
        this.inflater = inflater;
    }

    @NonNull
    @Override
    public View getView(int position,
                        @Nullable View convertView,
                        @NonNull ViewGroup parent) {
        View view = inflater.inflate(resource, parent, false);
        Metrorex metrou = metrouri.get(position);
        if (metrou != null) {
            addNumeStatie(view, metrou.getNumeStatie());
            addMagistrala(view, metrou.getMagistrala());
            addLegatura(view, metrou.getLegatura());
        }
        return view;
    }


    private void addNumeStatie(View view, String nume) {
        TextView tvNume = view.findViewById(R.id.id_tv_nume_statie);
        populateTextView(nume, tvNume);
    }

    private void addMagistrala(View view, String magistrala) {
        TextView tvMagistrala = view.findViewById(R.id.id_tv_magistrala);
        populateTextView(magistrala, tvMagistrala);
    }

    private void addLegatura(View view, String legatura) {
        TextView tvLegatura = view.findViewById(R.id.id_tv_legatura);
        populateTextView(legatura, tvLegatura);
    }



    private void populateTextView(String val, TextView tv) {
        if (val != null && !val.isEmpty()) {
            tv.setText(val);
        } else {
            tv.setText(R.string.tv_fara_date);
        }
    }

}
