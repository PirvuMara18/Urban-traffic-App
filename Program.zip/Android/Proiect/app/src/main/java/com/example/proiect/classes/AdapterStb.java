package com.example.proiect.classes;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.proiect.R;

import java.util.List;

public class AdapterStb extends ArrayAdapter<Stb> {

    private Context context;
    private int resource;
    private List<Stb> autovehicule;
    private LayoutInflater inflater;


    public AdapterStb(@NonNull Context context,
                           int resource, @NonNull List<Stb> objects,
                           LayoutInflater inflater) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
        this.autovehicule = objects;
        this.inflater = inflater;
    }

    @NonNull
    @Override
    public View getView(int position,
                        @Nullable View convertView,
                        @NonNull ViewGroup parent) {
        View view = inflater.inflate(resource, parent, false);
        Stb autovehicul = autovehicule.get(position);
        if (autovehicul != null) {
            addNrAutovehicul(view, autovehicul.getNumar());
            addTip(view, autovehicul.getTip());
            addTraseu(view, autovehicul.getTraseu());
        }
        return view;
    }


    private void addNrAutovehicul(View view, int nr) {
        TextView tvNr = view.findViewById(R.id.id_tv_nr_autovehicul);
        populateTextView(String.valueOf(nr), tvNr);
    }

    private void addTip(View view, String tip) {
        TextView tvTip = view.findViewById(R.id.id_tv_tip_autovehicul);
        populateTextView(tip, tvTip);
    }

    private void addTraseu(View view, String traseu) {
        TextView tvTraseu = view.findViewById(R.id.id_tv_traseu);
        populateTextView(traseu, tvTraseu);
    }


    private void populateTextView(String val, TextView tv) {
        if (val != null && !val.isEmpty()) {
            tv.setText(val);
        } else {
            tv.setText(R.string.tv_fara_date);
        }
    }


}
