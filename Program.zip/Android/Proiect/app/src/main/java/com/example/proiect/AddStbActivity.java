package com.example.proiect;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.proiect.classes.HartaStb;
import com.example.proiect.classes.Metrorex;
import com.example.proiect.classes.Stb;

import static android.widget.ArrayAdapter.createFromResource;

public class AddStbActivity extends AppCompatActivity {

    ImageButton imgHartaStb;
    public static final String STB_KEY = "stbkey";
    private Intent intent;
    private EditText etNumar;
    private Spinner spnTip;
    private EditText etTraseu;
    private Button btnAdaugare;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_stb);
        intent=getIntent();

        imgHartaStb=findViewById(R.id.id_img_harta_stb);
        etNumar=findViewById(R.id.id_et_nr_autovehicul);
        spnTip=findViewById(R.id.id_spn_tip);
        etTraseu=findViewById(R.id.id_et_traseu);
        btnAdaugare=findViewById(R.id.id_btn_salveaza_stb);
        addDateSpnStb();

        btnAdaugare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(validare_ok())
                {
                    int numarAutovehicul=Integer.parseInt(etNumar.getText().toString());
                    String tip= spnTip.getSelectedItem().toString();
                    String traseu = etTraseu.getText().toString();
                    Stb auto= new Stb(numarAutovehicul,tip,traseu);
                    intent.putExtra(STB_KEY, auto);
                    setResult(RESULT_OK, intent);
                    finish();
                }
            }
        });


        imgHartaStb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(getApplicationContext(), HartaStb.class);
                startActivity(intent);
            }
        });
    }


    private void addDateSpnStb()
    {
        ArrayAdapter<CharSequence> ad = createFromResource(getApplicationContext(),
                R.array.adaugare_tip_autovehicul,
                android.R.layout.simple_spinner_dropdown_item);
        spnTip.setAdapter(ad);

    }


    private boolean validare_ok() {
        if(etNumar.getText() == null || etNumar.getText().toString().trim().length() < 1 &&  etNumar.getText().toString().trim().length() > 4)
        {
            Toast.makeText(getApplicationContext(), R.string.numar_nepotrivit,Toast.LENGTH_LONG).show();
            return false;
        }

        if(etTraseu.getText() == null)
        {
            Toast.makeText(getApplicationContext(), R.string.traseu_nepotrivit, Toast.LENGTH_LONG).show();
            return false;
        }
        return true;
    }


}