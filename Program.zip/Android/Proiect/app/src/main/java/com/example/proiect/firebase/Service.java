package com.example.proiect.firebase;

import android.util.Log;

import androidx.annotation.NonNull;

import com.example.proiect.classes.Recenzie;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Service {

    private DatabaseReference db;
    private static Service service;
    private static final String RECENZIE_TBNAME = "recenzii";


    private Service(){

        db = FirebaseDatabase.getInstance().getReference(RECENZIE_TBNAME);
    }


    public static Service getElement() {
        if (service == null) {
            synchronized (Service.class) {
                if (service == null) {
                    service = new Service();
                }
            }
        }
        return service;
    }

    public void delete(Recenzie recenzie)
    {
        if(recenzie == null || recenzie.getId() == null || recenzie.getId().trim().isEmpty())
        {
            return;
        }
        db.child(recenzie.getId()).removeValue();

    }


    public void update_insert(Recenzie recenzie){
        if(recenzie == null)
        {
            return;
        }
        if(recenzie.getId() == null || recenzie.getId().trim().isEmpty()) {
            String id = db.push().getKey();
            recenzie.setId(id);

        }
        db.child(recenzie.getId()).setValue(recenzie);
    }


    public void addDataChange(final Callback<List<Recenzie>> callback){
        db.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<Recenzie> list = new ArrayList<>();
                for(DataSnapshot data: snapshot.getChildren()){
                    Recenzie recenzie = data.getValue(Recenzie.class);
                    if(recenzie != null)
                    {
                        list.add(recenzie);
                    }
                }
                callback.runResultOnUiThread(list);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.i("Service","NOT OK");

            }
        });
    }
}
