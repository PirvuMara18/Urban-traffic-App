package com.example.proiect.Database.DAO;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.proiect.Database.Model.Calator;

import java.util.List;


@Dao
public interface CalatorDao {

    @Query("SELECT * from Calatori")
    List<Calator> getAllTravelers();

    @Insert
    long insert(Calator calator);

    @Update
    int update(Calator calator);

    @Delete
    int delete(Calator calator);

}
