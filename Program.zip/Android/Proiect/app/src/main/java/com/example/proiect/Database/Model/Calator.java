package com.example.proiect.Database.Model;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "Calatori")
public class Calator {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "idCalator")
    long idCalator;
    @ColumnInfo(name = "nume")
    String nume;

    public Calator(long idCalator, String nume) {
        this.idCalator = idCalator;
        this.nume = nume;
    }

    public long getIdCalator() {
        return idCalator;
    }

    public void setIdCalator(long idCalator) {
        this.idCalator = idCalator;
    }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    @Override
    public String toString() {
        return "Calator{" +
                "idCalator=" + idCalator +
                ", nume='" + nume + '\'' +
                '}';
    }
}