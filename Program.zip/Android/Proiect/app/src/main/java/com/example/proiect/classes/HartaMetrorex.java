package com.example.proiect.classes;

import android.app.Activity;
import android.os.Bundle;
import android.util.DisplayMetrics;

import com.example.proiect.R;

public class HartaMetrorex extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.harta_metrorex);

        DisplayMetrics displaym =new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displaym);

        int width=displaym.widthPixels;
        int height=displaym.heightPixels;

        getWindow().setLayout((int)(width*.8),(int)(height*.5));

    }

}
