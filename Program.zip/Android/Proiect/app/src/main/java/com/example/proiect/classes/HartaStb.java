package com.example.proiect.classes;

import android.app.Activity;
import android.os.Bundle;
import android.util.DisplayMetrics;

import com.example.proiect.R;

public class HartaStb extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.harta_stb);

        DisplayMetrics displaym =new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displaym);

        int width=displaym.widthPixels;
        int height=displaym.heightPixels;

        getWindow().setLayout((int)(width*.9),(int)(height*.5));

    }
}
