package com.example.proiect.fragments;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.example.proiect.AddMetrorexActivity;
import com.example.proiect.MenuActivity;
import com.example.proiect.R;
import com.example.proiect.classes.AdapterMetrorex;
import com.example.proiect.classes.Metrorex;

import java.util.ArrayList;
import java.util.List;

import static android.app.Activity.RESULT_OK;


public class MetrorexFragment extends Fragment {

    public static final int ADD_METROREX_RC = 499;
    public static final String METROREX_KEY="metrorexkey";
    private Button btnAdaugare;
    private ListView lvMetrorex;
    private List<Metrorex> metrouri = new ArrayList<>();

    public MetrorexFragment() {
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.fragment_metrorex, container, false);

        btnAdaugare=view.findViewById(R.id.id_btn_add_metrorex);
        lvMetrorex=view.findViewById(R.id.id_lista_metrorex);

        Metrorex metrou1=new Metrorex("Eroilor","M3","M1-M5");
        Metrorex metrou2=new Metrorex("Basarab","M1","M4");
        Metrorex metrou3=new Metrorex("Unirii","M1","M2-M3");
        Metrorex metrou4=new Metrorex("Politehnica","M1","");
        Metrorex metrou5=new Metrorex("Titan","M1","");
        Metrorex metrou6=new Metrorex("Gara de Nord","M1","M4");

        metrouri.add(metrou1);
        metrouri.add(metrou2);
        metrouri.add(metrou3);
        metrouri.add(metrou4);
        metrouri.add(metrou5);
        metrouri.add(metrou6);


        if(getArguments() !=null)
        {
            metrouri = getArguments().getParcelableArrayList(METROREX_KEY);
        }

        if(getContext() !=null) {
            AdapterMetrorex adapter=new AdapterMetrorex(getContext().getApplicationContext(),
                    R.layout.metrorex_adapter, metrouri,getLayoutInflater());
            lvMetrorex.setAdapter(adapter);
        }
        btnAdaugare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getActivity(), AddMetrorexActivity.class);
                startActivityForResult(intent, ADD_METROREX_RC);
            }
        });

        return view;

    }

    public static MetrorexFragment instantaNoua(ArrayList<Metrorex> metrouri){
        MetrorexFragment fragment= new MetrorexFragment();
        Bundle bundle=new Bundle();
        bundle.putParcelableArrayList(MetrorexFragment.METROREX_KEY, metrouri);
        fragment.setArguments(bundle);
        return fragment;
    }


    public void notifyInternalAdapter(){
        ArrayAdapter adapter=(ArrayAdapter)lvMetrorex.getAdapter();
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == ADD_METROREX_RC && resultCode == RESULT_OK && data != null) {
            Metrorex metrou = (Metrorex) data.getParcelableExtra(AddMetrorexActivity.METROREX_KEY);
            if (metrou != null) {
                Toast.makeText(getContext().getApplicationContext(), metrou.toString(),
                        Toast.LENGTH_SHORT).show();
                metrouri.add(metrou);

                if (MenuActivity.actualFragment instanceof MetrorexFragment) {
                    ((MetrorexFragment) MenuActivity.actualFragment).notifyInternalAdapter();
                }
            }
        }

    }
}