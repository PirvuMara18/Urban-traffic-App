package com.example.proiect;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.WindowManager;

import com.example.proiect.fragments.DescriptionFragment;
import com.example.proiect.fragments.InfoFragment;
import com.example.proiect.fragments.MetrorexFragment;
import com.example.proiect.fragments.ScheduleFragment;
import com.example.proiect.fragments.StbFragment;
import com.google.android.material.navigation.NavigationView;


public class MenuActivity extends AppCompatActivity {


    private DrawerLayout drLayout;
    public static Fragment actualFragment;
    private NavigationView navView;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        Toolbar tlb = findViewById(R.id.toolbar);
        setSupportActionBar(tlb);
        drLayout = findViewById(R.id.drawerLayout);
        navView = findViewById(R.id.navmenu);
        ActionBarDrawerToggle drToggle = new ActionBarDrawerToggle(this, drLayout, tlb, R.string.navig_open, R.string.navig_close);
        drLayout.addDrawerListener(drToggle);
        drToggle.syncState();
        openDefaultFragment(savedInstanceState);
        navView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if (item.getItemId() == R.id.id_menu_info) {

                    actualFragment = new InfoFragment();
                    //Toast.makeText(getApplicationContext(),"Am deschis informatii", Toast.LENGTH_LONG).show();

                }
                if (item.getItemId() == R.id.id_menu_metrorex) {

                    actualFragment = new MetrorexFragment();
                    // Toast.makeText(getApplicationContext(),"Am deschis metrorex", Toast.LENGTH_LONG).show();
                }
                if (item.getItemId() == R.id.id_menu_stb) {

                    actualFragment = new StbFragment();
                    //Toast.makeText(getApplicationContext(),"Am deschis stb", Toast.LENGTH_LONG).show();
                }

                if (item.getItemId() == R.id.id_menu_orar) {

                    //  Toast.makeText(getApplicationContext(),"Am deschis orar", Toast.LENGTH_LONG).show();
                    actualFragment = new ScheduleFragment();

                }


                if (item.getItemId() == R.id.id_menu_review) {

                    //  Toast.makeText(getApplicationContext(),"Am deschis orar", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(getApplicationContext(), ReviewActivity.class);
                    startActivity(intent);

                }

                if (item.getItemId() == R.id.id_menu_despre) {

                    // Toast.makeText(getApplicationContext(),"Am deschis despre", Toast.LENGTH_LONG).show();
                    actualFragment = new DescriptionFragment();
                }

                openFragment();
                drLayout.closeDrawer(GravityCompat.START);
                return true;
            }
        });

    }




    private void openDefaultFragment(Bundle savedInstanceState) {
        if (savedInstanceState == null) {
            actualFragment =new InfoFragment();
            openFragment();

        }
    }

    private void openFragment() {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.id_container, actualFragment)
                .commit();
    }


}
