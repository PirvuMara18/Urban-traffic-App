package com.example.proiect.fragments;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.proiect.AddDataActivity;
import com.example.proiect.AddMetrorexActivity;
import com.example.proiect.BileteActivity;
import com.example.proiect.CarduriActivity;
import com.example.proiect.R;
import com.example.proiect.TraseeActivity;
import com.example.proiect.classes.HartaMetrorex;
import com.example.proiect.classes.Metrorex;

import java.util.ArrayList;


public class InfoFragment extends Fragment {
    public static final int ADD_DATA_RC=496;
    LinearLayout layoutBilete, layoutCarduri, layoutTrasee;
    ImageView imgBilete, imgCarduri, imgTrasee;
    TextView tvBilete, tvCarduri, tvTrasee;


    public InfoFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_info, container,false);

        layoutBilete=view.findViewById(R.id.layout_bilete);
        imgBilete=view.findViewById(R.id.img_bilete);
        tvBilete=view.findViewById(R.id.tb_bilete);

        layoutCarduri=view.findViewById(R.id.layout_carduri);
        imgCarduri=view.findViewById(R.id.img_carduri);
        tvCarduri=view.findViewById(R.id.tb_carduri);

        layoutTrasee=view.findViewById(R.id.layout_trasee);
        imgTrasee=view.findViewById(R.id.img_trasee);
        tvTrasee=view.findViewById(R.id.tb_trasee);

        tvBilete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getActivity(), BileteActivity.class);
                startActivityForResult(intent, ADD_DATA_RC);
            }
        });

        tvCarduri.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getActivity(), CarduriActivity.class);
                startActivityForResult(intent, ADD_DATA_RC);
            }
        });

        tvTrasee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getActivity(), TraseeActivity.class);
                startActivityForResult(intent, ADD_DATA_RC);
            }
        });

        return view;

    }
}