package com.example.proiect.network;

public class Autovehicul {
    private int numar;
    private String plecare;
    private String sosire;
    private Orar orar;

    public Autovehicul(int numar, String plecare, String sosire, Orar orar) {
        this.numar = numar;
        this.plecare = plecare;
        this.sosire = sosire;
        this.orar = orar;
    }

    public int getNumar() {
        return numar;
    }

    public void setNumar(int numar) {
        this.numar = numar;
    }

    public String getPlecare() {
        return plecare;
    }

    public void setPlecare(String plecare) {
        this.plecare = plecare;
    }

    public String getSosire() {
        return sosire;
    }

    public void setSosire(String sosire) {
        this.sosire = sosire;
    }

    public Orar getOrar() {
        return orar;
    }

    public void setOrar(Orar orar) {
        this.orar = orar;
    }

    @Override
    public String toString() {
        return "Autovehicul{" +
                "numar=" + numar +
                ", plecare='" + plecare + '\'' +
                ", sosire='" + sosire + '\'' +
                ", orar=" + orar +
                '}';
    }
}
