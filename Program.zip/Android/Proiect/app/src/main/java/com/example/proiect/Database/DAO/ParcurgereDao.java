package com.example.proiect.Database.DAO;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.proiect.Database.Model.Calator;
import com.example.proiect.Database.Model.Parcurgere;
import com.example.proiect.Database.Model.Traseu;

import java.util.List;

@Dao
public interface ParcurgereDao {

    @Insert
    long insert(Parcurgere parcurgere);

    @Update
    int update(Parcurgere parcurgere);

    @Update(onConflict = OnConflictStrategy.REPLACE)
    int update(List<Parcurgere> parcurgeres);

    @Delete
    int delete(Parcurgere parcurgere);

    @Query("Select * from Parcurgeri")
    List<Parcurgere> afiseazaToateParcurgerile();

    @Query("Select * from Calatori inner join Parcurgeri on " +
            "Calatori.idCalator = Parcurgeri.idC where" +
            " Parcurgeri.idT=:idT")
    List<Calator> afiseazaCalatoriPtTrasee(final int idT);

    @Query("Select * from Trasee inner join Parcurgeri on " +
            "Trasee.idTraseu = Parcurgeri.idT where" +
            " Parcurgeri.idC=:idC")
    List<Traseu> afiseazaTraseePtCalatori(final int idC);

}


