package com.example.proiect.Database.Model;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "Trasee")

public class Traseu {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "idTraseu")
    long idTraseu;
    @ColumnInfo(name = "mijloc_de_transport")
    String mijloc_de_transport;
    @ColumnInfo(name = "punct_de_plecare")
    String punct_de_plecare;
    @ColumnInfo(name = "punct_de_sosire")
    String punct_de_sosire;

    public Traseu(long idTraseu, String mijloc_de_transport, String punct_de_plecare, String punct_de_sosire) {
        this.idTraseu = idTraseu;
        this.mijloc_de_transport = mijloc_de_transport;
        this.punct_de_plecare = punct_de_plecare;
        this.punct_de_sosire = punct_de_sosire;
    }

    public long getIdTraseu() {
        return idTraseu;
    }

    public void setIdTraseu(long idTraseu) {
        this.idTraseu = idTraseu;
    }

    public String getMijloc_de_transport() {
        return mijloc_de_transport;
    }

    public void setMijloc_de_transport(String mijloc_de_transport) {
        this.mijloc_de_transport = mijloc_de_transport;
    }

    public String getPunct_de_plecare() {
        return punct_de_plecare;
    }

    public void setPunct_de_plecare(String punct_de_plecare) {
        this.punct_de_plecare = punct_de_plecare;
    }

    public String getPunct_de_sosire() {
        return punct_de_sosire;
    }

    public void setPunct_de_sosire(String punct_de_sosire) {
        this.punct_de_sosire = punct_de_sosire;
    }

    @Override
    public String toString() {
        return "Traseu{" +
                "idTraseu=" + idTraseu +
                ", mijloc_de_transport='" + mijloc_de_transport + '\'' +
                ", punct_de_plecare='" + punct_de_plecare + '\'' +
                ", punct_de_sosire='" + punct_de_sosire + '\'' +
                '}';
    }
}