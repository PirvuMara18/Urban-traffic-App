package com.example.proiect;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class CarduriActivity extends AppCompatActivity {

    TextView tvnumar, tvnume, tvluna, tvan, tvcvv;
    Button btncardnou;

    SharedPreferences sharedPreferences;
    private final String SHARED_PREF="sharedpref";
    private final String NR_KEY="numar";
    private final String NUME_KEY="nume";
    private final String LUNA_KEY="luna";
    private final String AN_KEY="an";
    private final String CVV_KEY="cvv";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carduri);

        tvnumar=findViewById(R.id.id_tv_numar);
        tvnume=findViewById(R.id.id_tv_nume);
        tvluna=findViewById(R.id.id_tv_luna);
        tvan=findViewById(R.id.id_tv_an);
        tvcvv=findViewById(R.id.id_tv_cvv);
        btncardnou=findViewById(R.id.id_btn_Adauga_card_nou);

        sharedPreferences=getSharedPreferences(SHARED_PREF,MODE_PRIVATE);
        String numar=sharedPreferences.getString(NR_KEY,null);
        String nume=sharedPreferences.getString(NUME_KEY,null);
        String luna=sharedPreferences.getString(LUNA_KEY,null);
        String an=sharedPreferences.getString(AN_KEY,null);
        String cvv=sharedPreferences.getString(CVV_KEY,null);

        if(numar!=null || nume!=null || luna!=null || an!=null || cvv!=null) {
            tvnumar.setText(String.format("Numar card - %s", numar));
            tvnume.setText(String.format("Nume titular - %s", nume));
            tvluna.setText(String.format("Luna expirare card - %s", luna));
            tvan.setText(String.format("An expirare card - %s", an));
            tvcvv.setText(String.format("CVV - %s", cvv));
        }

        btncardnou.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences.Editor editor=sharedPreferences.edit();
                editor.clear();
                editor.commit();
                finish();

                Intent intent= new Intent(getApplicationContext(), AddDataActivity.class);
                startActivity(intent);
            }
        });

    }
}
