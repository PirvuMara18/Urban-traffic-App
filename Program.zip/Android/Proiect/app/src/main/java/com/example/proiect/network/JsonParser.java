package com.example.proiect.network;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class JsonParser {
    public static HttpResponse parseJson(String json) {
        if (json == null) {
            return null;
        }
        try {
            JSONObject object = new JSONObject(json);
            List<Autovehicul> tramvaie = getItemListFromJson(object.getJSONArray("Tramvai"));
            List<Autovehicul> troleibuze = getItemListFromJson(object.getJSONArray("Autobuz"));
            List<Autovehicul> autobuze = getItemListFromJson(object.getJSONArray("Troleibuz"));
            return new HttpResponse(tramvaie,troleibuze,autobuze);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }
    

    private static Orar getOrarFromJs(JSONObject object) throws JSONException {
        if (object == null) {
            return null;
        }
        String zi = object.getString("Zi");
        String ora_inceput = object.getString("Ora_inceput");
        String ora_sfarsit = object.getString("Ora_sfarsit");
        return new Orar(zi, ora_inceput, ora_sfarsit);
    }

    private static List<Autovehicul> getItemListFromJson(JSONArray array) throws JSONException {
        if (array == null) {
            return null;
        }
        List<Autovehicul> results = new ArrayList<>();
        for (int i = 0; i < array.length(); i++) {
            Autovehicul item = getItemFromJson(array.getJSONObject(i));
            if (item != null) {
                results.add(item);
            }
        }
        return results;
    }

    private static Autovehicul getItemFromJson(JSONObject object) throws JSONException {
        if (object == null) {
            return null;
        }
        int numar = Integer.parseInt(object.getString("Numar"));
        String plecare = object.getString("Plecare");
        String sosire = object.getString("Sosire");
        Orar orar = getOrarFromJs(object.getJSONObject("Orar"));
        return new Autovehicul(numar, plecare, sosire, orar);
    }
}
