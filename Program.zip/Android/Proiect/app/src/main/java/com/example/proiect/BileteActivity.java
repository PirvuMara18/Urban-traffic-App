package com.example.proiect;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.text.MessageFormat;

public class BileteActivity extends AppCompatActivity  {

    TextView tvApp;
    Button btAchizitie;
    CheckBox checkBox1,checkBox2,checkBox3,checkBox4,checkBox5,checkBox6,checkBox7,checkBox8,checkBox9;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bilete);


        tvApp=findViewById(R.id.tv_selectie);
        btAchizitie=findViewById(R.id.id_btn_achizitioneaza);
        checkBox1=findViewById(R.id.checkbox1);
        checkBox2=findViewById(R.id.checkbox2);
        checkBox3=findViewById(R.id.checkbox3);
        checkBox4=findViewById(R.id.checkbox4);
        checkBox5=findViewById(R.id.checkbox5);
        checkBox6=findViewById(R.id.checkbox6);
        checkBox7=findViewById(R.id.checkbox7);
        checkBox8=findViewById(R.id.checkbox8);
        checkBox9=findViewById(R.id.checkbox9);



        btAchizitie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(date_valide()) {
                    String value = tvApp.getText().toString();
                    Intent intent = new Intent(getApplicationContext(), AddDataActivity.class);
                    intent.putExtra("total_key", value);
                    startActivity(intent);
                }
            }
        });

        Button btApp=findViewById(R.id.id_btn_aplica);
        btApp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(date_valide()) {

                    float sum = 0;
                    if (((CheckBox) findViewById(R.id.checkbox1)).isChecked()) sum += 1.3;
                    if (((CheckBox) findViewById(R.id.checkbox2)).isChecked()) sum += 8;
                    if (((CheckBox) findViewById(R.id.checkbox3)).isChecked()) sum += 20;
                    if (((CheckBox) findViewById(R.id.checkbox4)).isChecked()) sum += 35;
                    if (((CheckBox) findViewById(R.id.checkbox5)).isChecked()) sum += 2.5;
                    if (((CheckBox) findViewById(R.id.checkbox6)).isChecked()) sum += 5;
                    if (((CheckBox) findViewById(R.id.checkbox7)).isChecked()) sum += 8;
                    if (((CheckBox) findViewById(R.id.checkbox8)).isChecked()) sum += 20;
                    if (((CheckBox) findViewById(R.id.checkbox9)).isChecked()) sum += 70;

                    tvApp.setText(MessageFormat.format("{0}{1}{2}", getString(R.string.total), String.valueOf(sum), getString(R.string.ron)));

                }
            }
        });
    }

    private boolean date_valide() {
        if (!checkBox1.isChecked() && !checkBox2.isChecked() && !checkBox3.isChecked() && !checkBox4.isChecked()
                && !checkBox5.isChecked() && !checkBox6.isChecked() && !checkBox7.isChecked() && !checkBox8.isChecked() && !checkBox9.isChecked()){
            Toast.makeText(getApplicationContext(), R.string.selecteaza_optiune, Toast.LENGTH_LONG).show();
        return false;
    }
        return true;
    }

}
