package com.example.proiect.classes;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.proiect.R;
import com.example.proiect.network.Autovehicul;
import com.example.proiect.network.Orar;

import java.util.List;

public class NetworkAdapter extends ArrayAdapter<Autovehicul> {

    private Context context;
    private int resource;
    private List<Autovehicul> vehicles;
    private LayoutInflater inflater;


    public NetworkAdapter(@NonNull Context context,
                           int resource, @NonNull List<Autovehicul> objects,
                           LayoutInflater inflater) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
        this.vehicles = objects;
        this.inflater = inflater;
    }

    @NonNull
    @Override
    public View getView(int position,
                        @Nullable View convertView,
                        @NonNull ViewGroup parent) {
        View view = inflater.inflate(resource, parent, false);
        Autovehicul autovehicul= vehicles.get(position);
        if (autovehicul != null) {
            addNumarAutovehicul(view,autovehicul.getNumar());
            addStatiePlecare(view, autovehicul.getPlecare());
            addStatieSosire(view, autovehicul.getSosire());
            addZi(view, autovehicul.getOrar());
            addOraPlecare(view, autovehicul.getOrar());
            addOraSosire(view, autovehicul.getOrar());

        }
        return view;
    }


    private void addNumarAutovehicul(View view, int numar) {
        TextView tv_nr= view.findViewById(R.id.id_tv1);
        populateTextView(String.valueOf(numar), tv_nr);
    }

    private void addStatiePlecare(View view, String statie_plecare) {
        TextView tv_statie_plecare = view.findViewById(R.id.id_tv2);
        populateTextView(statie_plecare, tv_statie_plecare);
    }

    private void addStatieSosire(View view, String statie_sosire) {
        TextView tv_statie_sosire = view.findViewById(R.id.id_tv3);
        populateTextView(statie_sosire, tv_statie_sosire);
    }

    private void addZi(View view, Orar orar) {
        TextView tv_zi = view.findViewById(R.id.id_tv4);
        populateTextView(String.valueOf(orar.getZi()), tv_zi);
    }

    private void addOraPlecare(View view, Orar orar) {
        TextView tv_ora_plecare = view.findViewById(R.id.id_tv5);
        populateTextView(String.valueOf(orar.getOra_plecare()), tv_ora_plecare);
    }

    private void addOraSosire(View view, Orar orar) {
        TextView tv_ora_sosire = view.findViewById(R.id.id_tv6);
        populateTextView(String.valueOf(orar.getOra_sosire()), tv_ora_sosire);
    }



    private void populateTextView(String val, TextView tv) {
        if (val != null && !val.isEmpty()) {
            tv.setText(val);
        } else {
            tv.setText(R.string.tv_fara_date);
        }
    }
}
