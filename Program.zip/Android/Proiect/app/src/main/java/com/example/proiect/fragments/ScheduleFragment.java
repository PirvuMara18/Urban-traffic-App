package com.example.proiect.fragments;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import com.example.proiect.R;
import com.example.proiect.ScheduleMetrorexActivity;
import com.example.proiect.ScheduleStbActivity;


public class ScheduleFragment extends Fragment {

    private ImageButton imgOrarStb;
    private ImageButton imgOrarMetrorex;

    public ScheduleFragment() {


    }
        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                Bundle savedInstanceState) {
            View view = inflater.inflate(R.layout.fragment_schedule, container, false);
            imgOrarStb = view.findViewById(R.id.id_schedule_stb);
            imgOrarMetrorex = view.findViewById(R.id.id_schedule_metrorex);

            imgOrarStb.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent intent= new Intent(getActivity(), ScheduleStbActivity.class);
                    startActivity(intent);

                }
            });


            imgOrarMetrorex.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(getActivity(), ScheduleMetrorexActivity.class);
                    startActivity(intent);
                }
            });

            return view;





    }
}