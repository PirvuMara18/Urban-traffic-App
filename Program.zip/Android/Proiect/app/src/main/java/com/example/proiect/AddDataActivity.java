package com.example.proiect;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.proiect.fragments.InfoFragment;

import static android.widget.ArrayAdapter.createFromResource;

public class AddDataActivity extends AppCompatActivity {

    LinearLayout layout;
    private ImageView imgcard;
    private Intent intent;
    private EditText etNumarCard;
    private EditText etNumeTitular;
    private EditText etCvv;
    private EditText etLuna;
    private EditText etAn;
    private Button btnEfectueazaPlata, btnSalveaza;
    private TextView tvTotal;

    SharedPreferences sharedPreferences;
    private final String SHARED_PREF ="sharedpref";
    private final String NR_KEY ="numar";
    private final String NUME_KEY ="nume";
    private final String LUNA_KEY ="luna";
    private final String AN_KEY ="an";
    private final String CVV_KEY ="cvv";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_data);

        intent=getIntent();
        imgcard=findViewById(R.id.id_iv_card);
        etNumarCard=findViewById(R.id.id_et_nr_card);
        etNumeTitular=findViewById(R.id.id_et_nume_titular);
        etCvv=findViewById(R.id.id_et_cvv);
        etLuna=findViewById(R.id.id_et_luna);
        etAn=findViewById(R.id.id_et_an);
        btnEfectueazaPlata=findViewById(R.id.id_btn_efectueaza_plata);
        btnSalveaza=findViewById(R.id.id_btn_salveaza_date);
        tvTotal=findViewById(R.id.id_tv_total);


        tvTotal.setText(getIntent().getStringExtra("total_key"));


        sharedPreferences=getSharedPreferences(SHARED_PREF, MODE_PRIVATE);

        String numar=sharedPreferences.getString(NR_KEY, null);
        String nume=sharedPreferences.getString(NUME_KEY, null);
        String luna=sharedPreferences.getString(LUNA_KEY, null);
        String an=sharedPreferences.getString(AN_KEY, null);
        String cvv=sharedPreferences.getString(CVV_KEY, null);
        if(numar!=null || nume!=null || luna!=null || an!=null || cvv!=null)
        {
            Intent intent =new Intent(AddDataActivity.this, CarduriActivity.class);
            startActivity(intent);
        }
        btnSalveaza.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(date_valide()) {
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString(NR_KEY, etNumarCard.getText().toString());
                    editor.putString(NUME_KEY, etNumeTitular.getText().toString());
                    editor.putString(LUNA_KEY, etLuna.getText().toString());
                    editor.putString(AN_KEY, etAn.getText().toString());
                    editor.putString(CVV_KEY, etCvv.getText().toString());
                    editor.apply();

                    Intent intent = new Intent(getApplicationContext(), CarduriActivity.class);
                    startActivity(intent);

                    Toast.makeText(AddDataActivity.this, R.string.message, Toast.LENGTH_SHORT).show();
                }
        }
        });

        btnEfectueazaPlata.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(date_valide()) {
                    Toast.makeText(AddDataActivity.this, R.string.succes, Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        });
    }



    private boolean date_valide() {

        if (etNumarCard.getText() == null || etNumarCard.getText().toString().trim().length() < 16) {

            Toast.makeText(getApplicationContext(),
                    R.string.numar_card_invalid,
                    Toast.LENGTH_LONG)
                    .show();
            return false;
        }

        if (etNumeTitular.getText() == null || etNumeTitular.getText().toString().trim().length() < 6) {
            Toast.makeText(getApplicationContext(),
                    R.string.nume_invalid,
                    Toast.LENGTH_LONG)
                    .show();
            return false;
        }

        if (etLuna.getText() == null || Integer.parseInt(etLuna.getText().toString().trim()) < 1
                || Integer.parseInt(etLuna.getText().toString().trim()) > 12) {
            Toast.makeText(getApplicationContext(),
                    R.string.luna_invalida,
                    Toast.LENGTH_LONG)
                    .show();
            return false;
        }

        if (etAn.getText() == null || Integer.parseInt(etAn.getText().toString().trim()) < 2021) {
            Toast.makeText(getApplicationContext(),
                    R.string.an_invalid,
                    Toast.LENGTH_LONG)
                    .show();
            return false;
        }

        if (etCvv.getText() == null || etCvv.getText().toString().trim().length() < 3) {
            Toast.makeText(getApplicationContext(),
                    R.string.cvv_invalid,
                    Toast.LENGTH_LONG)
                    .show();
            return false;
        }
        return true;
    }
}
