package com.example.proiect.Database.DAO;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.proiect.Database.Model.Traseu;

import java.util.List;

@Dao
public interface TraseuDao {


    @Insert
    long insert(Traseu traseu);

    @Insert
    long [] insert(List<Traseu> trasee);

    @Update
    int update(Traseu traseu);

    @Delete
    int delete(Traseu traseu);

    @Query("Select * from Trasee")
    List<Traseu> getAllRoutes();
}
