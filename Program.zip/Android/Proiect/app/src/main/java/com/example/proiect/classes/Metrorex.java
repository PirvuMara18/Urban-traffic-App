package com.example.proiect.classes;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;

public class Metrorex implements Parcelable {

    private String numeStatie;
    private String magistrala;
    private String legatura;

    public Metrorex(String numeStatie, String magistrala, String legatura) {
        this.numeStatie = numeStatie;
        this.magistrala = magistrala;
        this.legatura = legatura;
    }

    protected Metrorex(Parcel in) {
        numeStatie = in.readString();
        magistrala = in.readString();
        legatura = in.readString();
    }

    public static final Creator<Metrorex> CREATOR = new Creator<Metrorex>() {
        @Override
        public Metrorex createFromParcel(Parcel in) {
            return new Metrorex(in);
        }

        @Override
        public Metrorex[] newArray(int size) {
            return new Metrorex[size];
        }
    };

    public String getNumeStatie() {
        return numeStatie;
    }

    public void setNumeStatie(String numeStatie) {
        this.numeStatie = numeStatie;
    }

    public String getMagistrala() {
        return magistrala;
    }

    public void setMagistrala(String magistrala) {
        this.magistrala = magistrala;
    }

    public String getLegatura() {
        return legatura;
    }

    public void setLegatura(String legatura) {
        this.legatura = legatura;
    }

    @Override
    public String toString() {
        return "Metrorex{" +
                "numeStatie='" + numeStatie + '\'' +
                ", magistrala='" + magistrala + '\'' +
                ", legatura='" + legatura + '\'' +
                '}';
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(numeStatie);
        dest.writeString(magistrala);
        dest.writeString(legatura);
    }
}
