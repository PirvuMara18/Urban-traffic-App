package com.example.proiect;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.proiect.classes.HartaMetrorex;
import com.example.proiect.classes.Metrorex;

import static android.widget.ArrayAdapter.createFromResource;

public class AddMetrorexActivity extends AppCompatActivity {

    public static final String METROREX_KEY = "metrorexkey";
    private ImageButton imgHartaMetrorex;
    private Intent intent;
    private EditText etNumeStatie;
    private Spinner spnMagistrala;
    private EditText etLegatura;
    private Button btnAdaugare;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_metrorex);
        intent=getIntent();

        imgHartaMetrorex=findViewById(R.id.id_img_harta_metrorex);
        etNumeStatie=findViewById(R.id.id_et_nr_autovehicul);
        etLegatura=findViewById(R.id.id_et_legatura);
        spnMagistrala=findViewById(R.id.id_spn_tip);
        btnAdaugare=findViewById(R.id.id_btn_salveaza_metrou);

        addDateSpnMetrorex();

        btnAdaugare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(validare_ok())
                {

                    String numeStatie = etNumeStatie.getText().toString();
                    String magistrala = spnMagistrala.getSelectedItem().toString();
                    String legatura = etLegatura.getText().toString();
                    Metrorex metrou= new Metrorex(numeStatie,magistrala,legatura);
                    intent.putExtra(METROREX_KEY, metrou);
                    setResult(RESULT_OK, intent);
                    finish();
                }
            }
        });


        imgHartaMetrorex.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(getApplicationContext(), HartaMetrorex.class);
                startActivity(intent);
            }
        });


    }

    private void addDateSpnMetrorex()
    {
        ArrayAdapter<CharSequence> ad = createFromResource(getApplicationContext(),
                R.array.adaugare_magistrala,
                android.R.layout.simple_spinner_dropdown_item);
        spnMagistrala.setAdapter(ad);

    }


    private boolean validare_ok() {
        if(etNumeStatie.getText() == null || etNumeStatie.getText().toString().trim().length() < 5)
        {
            Toast.makeText(getApplicationContext(), R.string.denumire_nepotrivita,Toast.LENGTH_LONG).show();
            return false;
        }

       return true;
    }

}