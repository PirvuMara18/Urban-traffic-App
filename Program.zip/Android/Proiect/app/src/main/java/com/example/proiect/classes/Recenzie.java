package com.example.proiect.classes;

import java.io.Serializable;

public class Recenzie implements Serializable {
   private String id;
    private String autovehicul;
    private int nota;
    private String text_recenzie;


    public Recenzie() {
    }

    public Recenzie(String id, String autovehicul, int nota, String text_recenzie) {
        this.id = id;
        this.autovehicul = autovehicul;
        this.nota = nota;
        this.text_recenzie = text_recenzie;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAutovehicul() {
        return autovehicul;
    }

    public void setAutovehicul(String autovehicul) {
        this.autovehicul = autovehicul;
    }

    public String getText_recenzie() {
        return text_recenzie;
    }

    public void setText_recenzie(String text_recenzie) {
        this.text_recenzie = text_recenzie;
    }

    public int getNota() {
        return nota;
    }

    public void setNota(int nota) {
        this.nota = nota;
    }
}
