package com.example.proiect;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.proiect.Database.DatabaseManager;
import com.example.proiect.Database.Model.Traseu;

import java.util.List;

class RecycleViewAdaper extends RecyclerView.Adapter<RecycleViewAdaper.MyViewHolder> {

    Context context;
    AlertDialog alertDialog;
    List<Traseu> traseus;
    DatabaseManager databaseManager;
    public RecycleViewAdaper(Context context, List<Traseu> traseus, DatabaseManager databaseManager) {

   this.traseus=traseus;
   this.databaseManager=databaseManager;
   this.context=context;

    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.trasee_item_layout, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        final Traseu traseu=traseus.get(position);
        holder.tvid.setText((int) traseu.getIdTraseu());
        holder.tvmijl.setText(traseu.getMijloc_de_transport());
        holder.tvsosire.setText(traseu.getPunct_de_sosire());
        holder.tvplecare.setText(traseu.getPunct_de_plecare());

        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                databaseManager.getTraseuDao().delete(traseu);
                traseus = databaseManager.getTraseuDao().getAllRoutes();
                notifyDataSetChanged();
            }
        });

        holder.edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setCancelable(true);
                View nview = LayoutInflater.from(context).inflate(R.layout.updateitem_layout, null);
                final EditText idTraseu= nview.findViewById(R.id.traseu_id);
                idTraseu.setText((int) traseu.getIdTraseu());
                final Spinner mijlocTransport= nview.findViewById(R.id.mijloc_transport);
                mijlocTransport.getSelectedItem().toString();
                final EditText punctplecare= nview.findViewById(R.id.pct_plecare);
                punctplecare.setText(traseu.getPunct_de_plecare());
                final EditText punctsosire= nview.findViewById(R.id.pct_sosire);
                punctsosire.setText(traseu.getPunct_de_sosire());

            }
        });

        View nview = LayoutInflater.from(context).inflate(R.layout.updateitem_layout, null);
        Button updateTraseu= nview.findViewById(R.id.modifica_traseu);
        updateTraseu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(traseu.getMijloc_de_transport()==null){
                    Toast.makeText(context, R.string.messaj_one, Toast.LENGTH_SHORT).show();
                }else if(traseu.getPunct_de_plecare()==null){
                    Toast.makeText(context, R.string.message_two, Toast.LENGTH_SHORT).show();
                }else if(traseu.getPunct_de_sosire()==null){
                    Toast.makeText(context, R.string.message_three, Toast.LENGTH_SHORT).show();
            }else{
                    databaseManager.getTraseuDao().update(traseu);
                    databaseManager.getTraseuDao().getAllRoutes();
                    notifyDataSetChanged();
                    alertDialog.dismiss();
                }
                }
        });

        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setView(nview);
        alertDialog=builder.create();
        alertDialog.show();

    }

    @Override
    public int getItemCount() {
        return traseus.size();
    }

    class MyViewHolder extends  RecyclerView.ViewHolder{

        TextView tvid, tvmijl, tvplecare, tvsosire;
        Button edit, delete;

        public MyViewHolder(@NonNull View itemView){
            super(itemView);

            tvid=itemView.findViewById(R.id.traseu_id);
            tvmijl=itemView.findViewById(R.id.mijloc_transport);
            tvplecare=itemView.findViewById(R.id.pct_plecare);
            tvsosire=itemView.findViewById(R.id.pct_sosire);
            edit=itemView.findViewById(R.id.modifica_traseu);
            delete=itemView.findViewById(R.id.sterge_traseu);

        }
    }
}
