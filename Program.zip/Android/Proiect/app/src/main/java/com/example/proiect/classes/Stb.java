package com.example.proiect.classes;

import android.os.Parcel;
import android.os.Parcelable;

public class Stb implements Parcelable {
    private int numar;
    private String tip;
    private String traseu;

    public Stb(int numar, String tip, String traseu) {
        this.numar = numar;
        this.tip = tip;
        this.traseu = traseu;
    }

    public Stb() {
    }

    protected Stb(Parcel in) {
        numar = in.readInt();
        tip = in.readString();
        traseu = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(numar);
        dest.writeString(tip);
        dest.writeString(traseu);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Stb> CREATOR = new Creator<Stb>() {
        @Override
        public Stb createFromParcel(Parcel in) {
            return new Stb(in);
        }

        @Override
        public Stb[] newArray(int size) {
            return new Stb[size];
        }
    };


    public int getNumar() {
        return numar;
    }

    public void setNumar(int numar) {
        this.numar = numar;
    }

    public String getTip() {
        return tip;
    }

    public void setTip(String tip) {
        this.tip = tip;
    }

    public String getTraseu() {
        return traseu;
    }

    public void setTraseu(String traseu) {
        this.traseu = traseu;
    }

    @Override
    public String toString() {
        return "Stb{" +
                ", numar=" + numar +
                ", tip='" + tip + '\'' +
                ", traseu='" + traseu + '\'' +
                '}';
    }


}
