package com.example.proiect.classes;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.proiect.R;

import java.util.List;

public class ReviewAdapter extends ArrayAdapter<Recenzie> {

    private Context context;
    private int resource;
    private List<Recenzie> recenzii;
    private LayoutInflater inflater;


    public ReviewAdapter(@NonNull Context context,
                           int resource, @NonNull List<Recenzie> objects,
                           LayoutInflater inflater) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
        this.recenzii = objects;
        this.inflater = inflater;
    }

    @NonNull
    @Override
    public View getView(int position,
                        @Nullable View convertView,
                        @NonNull ViewGroup parent) {
        View view = inflater.inflate(resource, parent, false);
        Recenzie recenzie = recenzii.get(position);
        if (recenzie != null) {
            addAutovehicul(view, recenzie.getAutovehicul());
            addNota(view, recenzie.getNota());
            addText(view, recenzie.getText_recenzie());
        }
        return view;
    }


    private void addAutovehicul(View view, String autovehicul) {
        TextView tv_autovehicul = view.findViewById(R.id.id_titlu_tv1_auto);
        populateTextView(autovehicul, tv_autovehicul);
    }

    private void addNota(View view, int nota) {
        TextView tv_nota = view.findViewById(R.id.id_titlu_tv2_nota);
        populateTextView(String.valueOf(nota), tv_nota);
    }

    private void addText(View view, String text) {
        TextView tv_text = view.findViewById(R.id.id_titlu_tv3_text);
        populateTextView(text, tv_text);
    }



    private void populateTextView(String val, TextView tv) {
        if (val != null && !val.isEmpty()) {
            tv.setText(val);
        } else {
            tv.setText(R.string.tv_fara_date);
        }
    }

}
