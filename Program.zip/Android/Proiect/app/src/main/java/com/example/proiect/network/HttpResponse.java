package com.example.proiect.network;

import java.util.List;

public class HttpResponse {
    List<Autovehicul> tramvaie,troleibuze,autobuze;
    
    public HttpResponse(List<Autovehicul> tramvaie, List<Autovehicul> troleibuze, List<Autovehicul> autobuze) {
        this.tramvaie = tramvaie;
        this.troleibuze = troleibuze;
        this.autobuze = autobuze;
    }

    public List<Autovehicul> getTramvaie() {
        return tramvaie;
    }

    public void setTramvaie(List<Autovehicul> tramvaie) {
        this.tramvaie = tramvaie;
    }

    public List<Autovehicul> getTroleibuze() {
        return troleibuze;
    }

    public void setTroleibuze(List<Autovehicul> troleibuze) {
        this.troleibuze = troleibuze;
    }

    public List<Autovehicul> getAutobuze() {
        return autobuze;
    }

    public void setAutobuze(List<Autovehicul> autobuze) {
        this.autobuze = autobuze;
    }

    @Override
    public String toString() {
        return "HttpResponse{" +
                "tramvaie=" + tramvaie +
                ", troleibuze=" + troleibuze +
                ", autobuze=" + autobuze +
                '}';
    }
}
