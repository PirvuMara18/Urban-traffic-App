package com.example.proiect.Database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

import com.example.proiect.Database.DAO.CalatorDao;
import com.example.proiect.Database.DAO.ParcurgereDao;
import com.example.proiect.Database.DAO.TraseuDao;
import com.example.proiect.Database.Model.Calator;
import com.example.proiect.Database.Model.Parcurgere;
import com.example.proiect.Database.Model.Traseu;
import com.example.proiect.classes.DateConverter;

@Database(entities = {Traseu.class, Calator.class, Parcurgere.class}, exportSchema = false, version = 1)
@TypeConverters({DateConverter.class})
public abstract class DatabaseManager extends RoomDatabase {

    private static final String TRASEE_PARCURSE_DB="tasee_parcurse_db";

    private static DatabaseManager databaseManager;

    public static DatabaseManager getInstance(Context context){
        if(databaseManager==null) {
            synchronized (DatabaseManager.class) {
                if (databaseManager == null) {

                    databaseManager = Room.databaseBuilder(context,
                            DatabaseManager.class, TRASEE_PARCURSE_DB)
                            .allowMainThreadQueries()
                            .build();
                }
            }
        }
        return databaseManager;
    }

    public abstract TraseuDao getTraseuDao();
    public abstract CalatorDao getCalatorDao();
    public abstract ParcurgereDao getParcurgereDao();
}
