package com.example.proiect.fragments;

import android.app.Service;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.example.proiect.AddMetrorexActivity;
import com.example.proiect.AddStbActivity;
import com.example.proiect.MenuActivity;
import com.example.proiect.R;
import com.example.proiect.classes.AdapterStb;
import com.example.proiect.classes.Metrorex;
import com.example.proiect.classes.Stb;

import java.util.ArrayList;
import java.util.List;

import static android.app.Activity.RESULT_OK;


public class StbFragment extends Fragment {

    public static final int ADD_STB_RC = 500;
    public static final String STB_KEY = "stbkey";
    private Button btnAdaugare;
    private ListView lvStb;
    private List<Stb> autovehicule = new ArrayList<>();

    public StbFragment() {
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_stb, container, false);
        btnAdaugare = view.findViewById(R.id.id_btn_add_stb);
        lvStb = view.findViewById(R.id.id_lista_stb);

        Stb autovehicul1 = new Stb(1, "Tramvai", "Bd. Banu Manta - Romprim");
        Stb autovehicul2 = new Stb(103, "Autobuz", "Isovolta - Cora Pantelimon");
        Stb autovehicul3 = new Stb(61, "Troleibuz", "Piata Rosetti - Master");
        Stb autovehicul4 = new Stb(105, "Autobuz", "Piata Presei - Valea Oltului");
        Stb autovehicul5 = new Stb(8, "Tramvai", "Zetarilor - Militari");
        Stb autovehicul6 = new Stb(65, "Troleibuz", "Sfintii Voievozi - Dridu");

        autovehicule.add(autovehicul1);
        autovehicule.add(autovehicul2);
        autovehicule.add(autovehicul3);
        autovehicule.add(autovehicul4);
        autovehicule.add(autovehicul5);
        autovehicule.add(autovehicul6);

        if (getArguments() != null) {
            autovehicule = getArguments().getParcelableArrayList(STB_KEY);
        }

        if (getContext() != null) {
            AdapterStb adapter = new AdapterStb(getContext().getApplicationContext(),
                    R.layout.stb_adapter, autovehicule,getLayoutInflater());
            lvStb.setAdapter(adapter);
        }
        btnAdaugare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), AddStbActivity.class);
                startActivityForResult(intent, ADD_STB_RC);

            }
        });

        return view;
    }


    public static StbFragment instantaNoua(ArrayList<Stb>autovehicule) {
        StbFragment fragment = new StbFragment();
        Bundle bundle = new Bundle();
        bundle.putParcelableArrayList(StbFragment.STB_KEY, autovehicule);
        fragment.setArguments(bundle);
        return fragment;
    }


    public void notifyInternalAdapter() {
        ArrayAdapter adapter = (ArrayAdapter) lvStb.getAdapter();
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == ADD_STB_RC && resultCode == RESULT_OK && data != null) {
            Stb autovehicul = (Stb) data.getParcelableExtra(AddStbActivity.STB_KEY);
            if (autovehicul != null) {
                Toast.makeText(getContext().getApplicationContext(), autovehicul.toString(),
                        Toast.LENGTH_SHORT).show();
                autovehicule.add(autovehicul);

                if (MenuActivity.actualFragment instanceof StbFragment) {
                    ((StbFragment) MenuActivity.actualFragment).notifyInternalAdapter();
                }
            }
        }
    }
}