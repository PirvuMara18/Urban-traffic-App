package com.example.proiect.Database.Model;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

import java.util.Date;

@Entity(tableName = "Parcurgeri",
        foreignKeys = {
                @ForeignKey(entity = Traseu.class, parentColumns = "idTraseu", childColumns = "idT"),
                @ForeignKey(entity = Calator.class, parentColumns = "idCalator", childColumns = "idC")
        })
public class Parcurgere {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "idParcurgere")
    long idParcurgere;
    @ColumnInfo(name = "idT", index = true)
    long idT;
    @ColumnInfo(name = "idC", index=true)
    long idC;
    @ColumnInfo(name = "dataParcurgere")
    Date dataParcurgere;

    public Parcurgere(long idParcurgere, long idT, long idC, Date dataParcurgere) {
        this.idParcurgere = idParcurgere;
        this.idT = idT;
        this.idC = idC;
        this.dataParcurgere = dataParcurgere;
    }

    public long getIdParcurgere() {
        return idParcurgere;
    }

    public void setIdParcurgere(long idParcurgere) {
        this.idParcurgere = idParcurgere;
    }

    public long getIdT() {
        return idT;
    }

    public void setIdT(long idT) {
        this.idT = idT;
    }

    public long getIdC() {
        return idC;
    }

    public void setIdC(long idC) {
        this.idC = idC;
    }

    public Date getDataParcurgere() {
        return dataParcurgere;
    }

    public void setDataParcurgere(Date dataParcurgere) {
        this.dataParcurgere = dataParcurgere;
    }

    @Override
    public String toString() {
        return "Parcurgere{" +
                "idParcurgere=" + idParcurgere +
                ", idT=" + idT +
                ", idC=" + idC +
                ", dataParcurgere=" + dataParcurgere +
                '}';
    }
}
