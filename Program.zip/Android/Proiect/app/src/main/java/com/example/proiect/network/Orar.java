package com.example.proiect.network;

public class Orar {
    private String zi;
    private String ora_plecare;
    private String ora_sosire;

    public Orar(String zi, String ora_plecare, String ora_sosire) {
        this.zi = zi;
        this.ora_plecare = ora_plecare;
        this.ora_sosire = ora_sosire;
    }

    public String getZi() {
        return zi;
    }

    public void setZi(String zi) {
        this.zi = zi;
    }

    public String getOra_plecare() {
        return ora_plecare;
    }

    public void setOra_plecare(String ora_plecare) {
        this.ora_plecare = ora_plecare;
    }

    public String getOra_sosire() {
        return ora_sosire;
    }

    public void setOra_sosire(String ora_sosire) {
        this.ora_sosire = ora_sosire;
    }

    @Override
    public String toString() {
        return "Orar{" +
                "zi='" + zi + '\'' +
                ", ora_plecare='" + ora_plecare + '\'' +
                ", ora_sosire='" + ora_sosire + '\'' +
                '}';
    }
}
