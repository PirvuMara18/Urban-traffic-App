package com.example.proiect;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.example.proiect.classes.NetworkAdapter;
import com.example.proiect.network.HttpManager;
import com.example.proiect.network.HttpResponse;
import com.example.proiect.network.Autovehicul;
import com.example.proiect.network.JsonParser;

import java.util.ArrayList;
import java.util.List;

public class ScheduleStbActivity extends AppCompatActivity {

    private final static String URL = "https://jsonkeeper.com/b/QY68";
    private HttpResponse httpResp;
    private List<Autovehicul> selectedVehicle = new ArrayList<>();
    private Button tramvai;
    private Button troleibuz;
    private Button autobuz;
    private ListView lvAutovehicule;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule_stb);

        new HttpManager() {
            @Override
            protected void onPostExecute(String s) {
                httpResp = JsonParser.parseJson(s);
            }
        }.execute(URL);


        tramvai = findViewById(R.id.id_btn_tramvai);
        troleibuz = findViewById(R.id.id_btn_troleibuz);
        autobuz = findViewById(R.id.id_btn_autobuz);
        lvAutovehicule = findViewById(R.id.id_lv_orar);


            NetworkAdapter adapter=new NetworkAdapter(getApplicationContext(),
                    R.layout.netw_adapter, selectedVehicle, getLayoutInflater());
            lvAutovehicule.setAdapter(adapter);


      //  ArrayAdapter<Item> adapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1, selectedItem);
       // lvAutovehicule.setAdapter(adapter);
        unselectedButtons();

        tramvai.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (httpResp != null && httpResp.getTramvaie() != null) {
                    unselectedButtons();
                    selectButton(tramvai);
                    selectResponse(httpResp.getTramvaie());
                }
            }
        });

        troleibuz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (httpResp != null && httpResp.getTroleibuze() != null) {
                    unselectedButtons();
                    selectButton(troleibuz);
                    selectResponse(httpResp.getTroleibuze());
                }
            }
        });

        autobuz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (httpResp != null && httpResp.getAutobuze() != null) {
                    unselectedButtons();
                    selectButton(autobuz);
                    selectResponse(httpResp.getAutobuze());
                }
            }
        });
    }

    private void selectResponse(List<Autovehicul> list) {
        selectedVehicle.clear();
        selectedVehicle.addAll(list);
        ArrayAdapter<Autovehicul> adapter = (ArrayAdapter<Autovehicul>) lvAutovehicule.getAdapter();
        adapter.notifyDataSetChanged();
    }

    private void unselectedButtons() {
        tramvai.setBackgroundColor(Color.BLACK);
        troleibuz.setBackgroundColor(Color.BLACK);
        autobuz.setBackgroundColor(Color.BLACK);
    }

    private void selectButton(Button button) {
        button.setBackgroundColor(Color.LTGRAY);
    }




    }
