package com.example.proiect;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;

import com.example.proiect.Database.DAO.CalatorDao;
import com.example.proiect.Database.DAO.ParcurgereDao;
import com.example.proiect.Database.DAO.TraseuDao;
import com.example.proiect.Database.DatabaseManager;
import com.example.proiect.Database.Model.Calator;
import com.example.proiect.Database.Model.Parcurgere;
import com.example.proiect.Database.Model.Traseu;

import java.util.ArrayList;
import java.util.List;

public class TraseeActivity extends AppCompatActivity implements SwipeRefreshLayout.OnRefreshListener {

    private RecyclerView rvTrasee;
    private Button btnVizualizarerapoarte,btnAdauga;
    public TraseuDao daoT;
    public List<Traseu> traseus=new ArrayList<>();
    private DatabaseManager databaseManager;
    private SwipeRefreshLayout swipeRefreshLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trasee);
        //daoT=DatabaseManager.getInstance(this).getTraseuDao();

        swipeRefreshLayout=findViewById(R.id.swipe);
        swipeRefreshLayout.setOnRefreshListener(this);
        btnVizualizarerapoarte = findViewById(R.id.vizualizare_rapoarte_btn);
        btnAdauga=findViewById(R.id.Adauga_Traseu_btn);
        // getAllTravelers();

        btnAdauga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(), AddTraseuActivity.class);
                startActivity(intent);
            }
        });

        databaseManager=DatabaseManager.getInstance(getApplicationContext());

        rvTrasee=findViewById(R.id.trasee_rv);

    }

    /*public void getAllTravelers(){
        swipeRefreshLayout.setRefreshing(true);
        traseus=databaseManager.getTraseuDao().getAllRoutes();
        RecyclerView.Adapter adapter=new RecycleViewAdaper(TraseeActivity.this, traseus,databaseManager);
    rvTrasee.setAdapter(adapter);
    adapter.notifyDataSetChanged();
    swipeRefreshLayout.setRefreshing(false);
    }*/
    @Override
    public void onRefresh() {

        //getAllTravelers();

    }
}
