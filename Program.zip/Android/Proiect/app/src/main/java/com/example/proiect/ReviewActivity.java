package com.example.proiect;

import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.proiect.classes.Recenzie;
import com.example.proiect.classes.ReviewAdapter;
import com.example.proiect.firebase.Callback;
import com.example.proiect.firebase.Service;

import java.util.ArrayList;
import java.util.List;


public class ReviewActivity extends AppCompatActivity {

    private Service firebaseService;
    private RadioGroup rgAutovehicul;
    private RadioButton radioButton,radioButton2,radioButton3,radioButton4;
    private List<RadioButton> btns = new ArrayList<>();
    private EditText etText;
    private Spinner nota;
    private Button btnInsert, btnStergere, btnDelete;
    private ListView lvReviews;
    private List<Recenzie> recenzii = new ArrayList<>();
    private int selectedReviewIndex = -1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review);
        initComponents();
        firebaseService = Service.getElement();
        firebaseService.addDataChange(eventCallback());

    }

    private void initComponents() {
        rgAutovehicul=findViewById(R.id.rg_autovehicul);
        radioButton=findViewById(R.id.rb_metrou);
        radioButton2=findViewById(R.id.rb_tramvai);
        radioButton3=findViewById(R.id.rb_troleibuz);
        radioButton4=findViewById(R.id.rb_add_autobuz);
        btns.add(radioButton);
        btns.add(radioButton2);
        btns.add(radioButton3);
        btns.add(radioButton4);
        etText=findViewById(R.id.id_et_text_recenzie);
        nota=findViewById(R.id.id_spinner_nota);
        btnStergere = findViewById(R.id.id_btn_update);
        btnDelete = findViewById(R.id.id_btn_delete);
        btnInsert = findViewById(R.id.id_btn_insert);
        lvReviews = findViewById(R.id.lv_reviews);
        setSpnAdapter();
        setLvAdapter();
        btnStergere.setOnClickListener(clearEvent());
        btnDelete.setOnClickListener(deleteEvent());
        btnInsert.setOnClickListener(saveEvent());
        lvReviews.setOnItemClickListener(SelectEventListener());
    }

    private void setSpnAdapter() {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getApplicationContext(),
                R.array.adaugare_nota, android.R.layout.simple_spinner_dropdown_item);
        nota.setAdapter(adapter);
    }

    private void setLvAdapter() {
        ReviewAdapter adapter = new ReviewAdapter(getApplicationContext(), R.layout.review_adapter,
                recenzii, getLayoutInflater());
        lvReviews.setAdapter(adapter);
    }

    private AdapterView.OnItemClickListener SelectEventListener() {
        return new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                selectedReviewIndex = position;
                String den = recenzii.get(selectedReviewIndex).getAutovehicul();
                for(RadioButton rb : btns){
                    if(rb.getText().toString().trim().equals(den))
                        rb.setChecked(true);
                        else
                        Log.i("da", "err da");

                }
                etText.setText(recenzii.get(selectedReviewIndex).getText_recenzie());
                selectGrade(recenzii.get(selectedReviewIndex).getNota());
           }
        };
    }

    private void selectGrade(int notaRecenzie) {
        ArrayAdapter<String> adapter = (ArrayAdapter<String>) nota.getAdapter();
        for (int i = 0; i < adapter.getCount(); i++) {
            if (adapter.getItem(i).equals(String.valueOf(notaRecenzie))) {
                nota.setSelection(i);
                break;
            }
        }
    }

    private View.OnClickListener saveEvent() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validate()) {
                    Recenzie recenzie = createReview();
                    firebaseService.update_insert(recenzie);

                }
            }
        };
    }

    private Recenzie createReview() {
        String id = selectedReviewIndex != -1? recenzii.get(selectedReviewIndex).getId():null;

        int selectedId = rgAutovehicul.getCheckedRadioButtonId();
        radioButton = (RadioButton) findViewById(selectedId);
        String denumire_autovehicule = radioButton.getText().toString();
        int notaRecenzie =Integer.parseInt(nota.getSelectedItem().toString().trim());
        String text = etText.getText().toString();

        return new Recenzie(id, denumire_autovehicule, notaRecenzie, text);
    }

    private View.OnClickListener deleteEvent() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedReviewIndex != -1) {
                    firebaseService.delete(recenzii.get(selectedReviewIndex));
                }
            }
        };
    }

    private View.OnClickListener clearEvent() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearFields();
            }
        };
    }

    private boolean validate() {
        if (etText.getText() == null || etText.getText().toString().trim().isEmpty()) {
            Toast.makeText(getApplicationContext(), R.string.message_error, Toast.LENGTH_LONG).show();
            return false;

        }

        return true;
    }
    
    private void clearFields() {
        rgAutovehicul.clearCheck();
        nota.setSelection(0);
        etText.setText(null);
        selectedReviewIndex = -1;
    }

    private Callback<List<Recenzie>> eventCallback(){
        return new Callback<List<Recenzie>>() {
            @Override
            public void runResultOnUiThread(List<Recenzie> result) {
                if(result != null)
                {
                   recenzii.clear();
                   recenzii.addAll(result);
                   notifyLvAdapter();
                   clearFields();

                }
            }
        };
    }

    private void notifyLvAdapter() {
        ReviewAdapter reviewAdapter = (ReviewAdapter) lvReviews.getAdapter();
        reviewAdapter.notifyDataSetChanged();
    }

}