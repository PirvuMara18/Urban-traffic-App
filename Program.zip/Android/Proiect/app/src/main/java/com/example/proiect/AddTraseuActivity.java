package com.example.proiect;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

public class AddTraseuActivity extends AppCompatActivity {

    private TextInputEditText tieId;
    private TextInputEditText tiePlecare;
    private Spinner spnMijloc;
    private TextInputEditText tieSosire;
    private Button btnSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_traseu);

        tieId = findViewById(R.id.tiet_ID);
        tiePlecare = findViewById(R.id.tiet_punct_plecare);
        tieSosire = findViewById(R.id.tiet_punct_sosire);
        spnMijloc = findViewById(R.id.spn_mijloc_de_transport);
        btnSave = findViewById(R.id.btn_salvare_traseu);

        addMijlocAdapter();

    }

    private void addMijlocAdapter() {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getApplicationContext(),
                R.array.adaugare_mijloc_de_transport,
                android.R.layout.simple_spinner_dropdown_item);
        spnMijloc.setAdapter(adapter);
    }

    private boolean validate() {
        if (tieId.getText() == null || tieId.getText().toString().isEmpty()
                || Double.parseDouble(tieId.getText().toString()) < 0) {
            Toast.makeText(getApplicationContext(),
                    R.string.eroare_id,
                    Toast.LENGTH_SHORT)
                    .show();
            return false;
        }
        if (tiePlecare.getText() == null || tiePlecare.getText().toString().isEmpty()
                || Double.parseDouble(tiePlecare.getText().toString()) < 0) {
            Toast.makeText(getApplicationContext(),
                    R.string.necompletare_camp,
                    Toast.LENGTH_SHORT)
                    .show();
            return false;
        }
        if (tieSosire.getText() == null || tieSosire.getText().toString().isEmpty()
                || Double.parseDouble(tieSosire.getText().toString()) < 0) {
            Toast.makeText(getApplicationContext(),
                    R.string.necompletare_camp,
                    Toast.LENGTH_SHORT)
                    .show();
            return false;
        }
        return true;
    }
}
